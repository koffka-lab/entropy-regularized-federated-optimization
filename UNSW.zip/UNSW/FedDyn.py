"""
FedYogi on UNSW-NB15  (corrected gradient sign, bias-corrected moments)
=======================================================================
Dirichlet α = 0.5      |   K = 5 non-IID clients
IID warm-up           : 5 % of data, 1 epoch (Adam, lr=1e-3)
Local training        : Adam (lr=1e-3, 1 epoch, batch=64)
Server optimizer      : Yogi (η = 0.10, β1 = 0.9, β2 = 0.99, τ = 1e-6)
Communication rounds  : 100
Metrics per round     : Accuracy (%) and Macro-F1
Seeds                 : [42, 43, 44]
"""

import os, random
import numpy as np, pandas as pd, torch
import torch.nn as nn, torch.nn.functional as F
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.metrics import accuracy_score, f1_score
from torch.utils.data import TensorDataset, DataLoader

# ───────── hyperparameters ─────────
DATA_DIR    = "./data"
K           = 5
ROUNDS      = 100
DIRICHLET_A = 0.5
WARMUP_FR   = 0.05
LR_LOCAL    = 1e-3
EPOCHS_LOC  = 1
BATCH       = 64
SEEDS       = [42, 43, 44]

# FedYogi server parameters
ETA_S, B1, B2, TAU = 0.10, 0.9, 0.99, 1e-6

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ───────── model ─────────
class MLP(nn.Module):
    def __init__(self, d_in, h=64, n_out=2):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(d_in, h), nn.ReLU(),
            nn.Linear(h, h), nn.ReLU(),
            nn.Linear(h, n_out),
        )
    def forward(self, x):
        return self.net(x)

# ───────── data loading & preprocessing ─────────
def load_unsw():
    tr = pd.read_csv(os.path.join(DATA_DIR, "UNSW_NB15_training-set.csv"))
    te = pd.read_csv(os.path.join(DATA_DIR, "UNSW_NB15_testing-set.csv"))

    num_cols = tr.select_dtypes(include="number").columns.drop(["id", "label"])
    cat_cols = [c for c in tr.columns if tr[c].dtype == "object" and c != "attack_cat"]

    impN, impC = SimpleImputer(strategy="median"), SimpleImputer(strategy="most_frequent")
    tr[num_cols], te[num_cols] = impN.fit_transform(tr[num_cols]), impN.transform(te[num_cols])
    tr[cat_cols], te[cat_cols] = impC.fit_transform(tr[cat_cols]), impC.transform(te[cat_cols])

    enc = OneHotEncoder(sparse=False, handle_unknown="ignore")
    trC, teC = enc.fit_transform(tr[cat_cols]), enc.transform(te[cat_cols])
    scl = StandardScaler()
    trN, teN = scl.fit_transform(tr[num_cols]), scl.transform(te[num_cols])

    Xtr = np.hstack([trN, trC]).astype(np.float32)
    Xte = np.hstack([teN, teC]).astype(np.float32)
    ytr = tr["label"].values.astype(int)
    yte = te["label"].values.astype(int)
    return Xtr, ytr, Xte, yte

Xtr, ytr, Xte, yte = load_unsw()
D_IN, N_CLASS = Xtr.shape[1], len(np.unique(ytr))

# ───────── single-run function ─────────
def run(seed: int):
    # reproducibility
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    # IID warm-up
    idx0 = np.random.choice(len(Xtr), int(WARMUP_FR * len(Xtr)), replace=False)
    warm_model = MLP(D_IN, n_out=N_CLASS).to(device)
    opt0 = torch.optim.Adam(warm_model.parameters(), lr=1e-3)
    loader0 = DataLoader(
        TensorDataset(torch.from_numpy(Xtr[idx0]), torch.from_numpy(ytr[idx0])),
        batch_size=128, shuffle=True
    )
    warm_model.train()
    for xb, yb in loader0:
        xb, yb = xb.to(device), yb.to(device)
        opt0.zero_grad()
        F.cross_entropy(warm_model(xb), yb).backward()
        opt0.step()

    global_w = [p.data.clone() for p in warm_model.parameters()]

    # initialise FedYogi moments
    m_t = [torch.zeros_like(w) for w in global_w]
    v_t = [torch.zeros_like(w) for w in global_w]

    # Dirichlet non-IID split
    clients = {i: [] for i in range(K)}
    for cls in np.unique(ytr):
        idxs = np.where(ytr == cls)[0]
        props = np.random.dirichlet([DIRICHLET_A] * K)
        cuts = (np.cumsum(props) * len(idxs)).astype(int)
        start = 0
        for i, end in enumerate(cuts):
            clients[i].extend(idxs[start:end].tolist())
            start = end

    # communication rounds
    for r in range(ROUNDS):
        deltas, sizes = [], []

        # local updates
        for cid in range(K):
            local = MLP(D_IN, n_out=N_CLASS).to(device)
            for p, w in zip(local.parameters(), global_w):
                p.data.copy_(w)
            opt_loc = torch.optim.Adam(local.parameters(), lr=LR_LOCAL)

            ds = TensorDataset(
                torch.from_numpy(Xtr[clients[cid]]),
                torch.from_numpy(ytr[clients[cid]])
            )
            ld = DataLoader(ds, batch_size=BATCH, shuffle=True)

            local.train()
            for _ in range(EPOCHS_LOC):
                for xb, yb in ld:
                    xb, yb = xb.to(device), yb.to(device)
                    opt_loc.zero_grad()
                    F.cross_entropy(local(xb), yb).backward()
                    opt_loc.step()

            deltas.append([p.data - w for p, w in zip(local.parameters(), global_w)])
            sizes.append(len(clients[cid]))

        total = sum(sizes)
        # correct FedYogi gradient: global - local
        g_t = [
            -sum(sz * delta for sz, delta in zip(sizes, grads)) / total
            for grads in zip(*deltas)
        ]

        # FedYogi server update with bias correction
        with torch.no_grad():
            for i, (w, g) in enumerate(zip(global_w, g_t)):
                m_t[i] = B1 * m_t[i] + (1 - B1) * g
                v_t[i] = v_t[i] + (1 - B2) * torch.sign((g * g) - v_t[i]) * (g * g)

                # bias correction
                m_hat = m_t[i] / (1 - B1 ** (r + 1))
                v_hat = v_t[i] / (1 - B2 ** (r + 1))

                step = ETA_S * m_hat / (torch.sqrt(v_hat) + TAU)
                w.data -= step

        # evaluation
        eval_model = MLP(D_IN, n_out=N_CLASS).to(device).eval()
        with torch.no_grad():
            for p, w in zip(eval_model.parameters(), global_w):
                p.data.copy_(w)
            preds = eval_model(torch.from_numpy(Xte).to(device)).argmax(1).cpu().numpy()

        acc = accuracy_score(yte, preds) * 100
        f1  = f1_score(yte, preds, average="macro")
        print(f"[Seed {seed}] Round {r+1:3d} → Acc={acc:6.2f}%   Macro-F1={f1:5.3f}")

# ───────── execute three seeds ─────────
for s in SEEDS:
    run(s)
