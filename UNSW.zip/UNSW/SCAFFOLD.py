# ============================================================
#  SCAFFOLD on UNSW-NB15, averaged over 3 runs (live output)
# ============================================================

import os
import random
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.metrics import accuracy_score, f1_score
from torch.utils.data import DataLoader, TensorDataset
import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm import trange

# ---------------------------
# 0) Preprocess once
# ---------------------------
DATA_DIR = "./data"
train_df = pd.read_csv(os.path.join(DATA_DIR, "UNSW_NB15_training-set.csv"))
test_df  = pd.read_csv(os.path.join(DATA_DIR, "UNSW_NB15_testing-set.csv"))

# numeric vs categorical
num_cols = train_df.select_dtypes(include="number").columns.drop(["id","label"])
cat_cols = [c for c in train_df.columns if train_df[c].dtype=="object" and c!="attack_cat"]

# -- IMPUTE --
# numeric → median
num_imp = SimpleImputer(strategy="median")
train_df[num_cols] = num_imp.fit_transform(train_df[num_cols])
test_df [num_cols] = num_imp.transform(test_df [num_cols])

# categorical → most frequent
cat_imp = SimpleImputer(strategy="most_frequent")
train_df[cat_cols] = cat_imp.fit_transform(train_df[cat_cols])
test_df [cat_cols] = cat_imp.transform(test_df [cat_cols])

# -- ENCODE & SCALE --
ohe        = OneHotEncoder(sparse=False, handle_unknown="ignore")
train_cat  = ohe.fit_transform(train_df[cat_cols])
test_cat   = ohe.transform(test_df[cat_cols])

scaler     = StandardScaler()
train_num  = scaler.fit_transform(train_df[num_cols])
test_num   = scaler.transform(test_df[num_cols])

X_train = np.hstack([train_num, train_cat]).astype(np.float32)
X_test  = np.hstack([test_num,  test_cat]).astype(np.float32)
y_train = train_df["label"].values.astype(int)
y_test  = test_df["label"].values.astype(int)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ---------------------------
# 1) Model & SCAFFOLD helpers
# ---------------------------
class MLP(nn.Module):
    def __init__(self, in_dim, h=64, num_classes=10):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, h), nn.ReLU(),
            nn.Linear(h,     h), nn.ReLU(),
            nn.Linear(h, num_classes)
        )
    def forward(self, x):
        return self.net(x)

def local_train_scaffold(w0, c0, ci, indices, lr=1e-3, batch_size=64):
    m = MLP(X_train.shape[1]).to(device)
    for p,w in zip(m.parameters(), w0):
        p.data.copy_(w)
    opt = torch.optim.SGD(m.parameters(), lr=lr)
    ds  = TensorDataset(torch.from_numpy(X_train[indices]),
                        torch.from_numpy(y_train[indices]))
    loader = DataLoader(ds, batch_size=batch_size, shuffle=True)

    # one pass through local data
    for xb,yb in loader:
        xb,yb = xb.to(device), yb.to(device)
        opt.zero_grad()
        F.cross_entropy(m(xb), yb).backward()
        # adjust grads with control variates
        for p, sc, cc in zip(m.parameters(), c0, ci):
            if p.grad is not None:
                p.grad.data += (sc - cc).to(device)
        opt.step()

    # compute delta_w and new client control variate
    delta_w, new_ci = [], []
    n_i = len(indices)
    for p, w, sc, cc in zip(m.parameters(), w0, c0, ci):
        d = (p.data - w).clone()
        delta_w.append(d)
        new_ci.append(cc - sc + d / n_i)
    return delta_w, new_ci

def run_scaffold(seed):
    # reproducibility
    random.seed(seed); np.random.seed(seed)
    torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark     = False

    # -- small IID warm-up --
    warm_frac = 0.05
    n_warm    = int(len(X_train)*warm_frac)
    warm_idx  = np.random.choice(len(X_train), n_warm, replace=False)
    warm_ds   = TensorDataset(torch.from_numpy(X_train[warm_idx]),
                              torch.from_numpy(y_train[warm_idx]))
    warm_loader = DataLoader(warm_ds, batch_size=128, shuffle=True)

    # initialize global model
    model    = MLP(X_train.shape[1]).to(device)
    opt_warm = torch.optim.Adam(model.parameters(), lr=1e-3)
    model.train()
    for xb,yb in warm_loader:
        xb,yb = xb.to(device), yb.to(device)
        opt_warm.zero_grad()
        F.cross_entropy(model(xb), yb).backward()
        opt_warm.step()
    global_w = [p.data.clone() for p in model.parameters()]

    # Dirichlet non-IID split
    K, alpha = 5, 0.5
    client_idxs = {i: [] for i in range(K)}
    for c in np.unique(y_train):
        idxs  = np.where(y_train==c)[0]
        props = np.random.dirichlet([alpha]*K)
        splits = (np.cumsum(props)*len(idxs)).astype(int)
        prev = 0
        for i,pt in enumerate(splits):
            client_idxs[i] += idxs[prev:pt].tolist()
            prev = pt

    # init control variates
    server_c = [torch.zeros_like(p) for p in global_w]
    client_c = {i:[torch.zeros_like(p) for p in global_w] for i in range(K)}

    # federated loop
    ROUNDS = 100
    acc_hist, f1_hist = [], []

    for rnd in trange(ROUNDS, desc=f"SCAFFOLD seed {seed}"):
        deltas, sizes = [], []
        for cid in range(K):
            dW, next_ci = local_train_scaffold(
                global_w, server_c, client_c[cid], client_idxs[cid]
            )
            client_c[cid] = next_ci
            deltas.append(dW)
            sizes.append(len(client_idxs[cid]))

        tot = sum(sizes)
        # aggregate global weights
        with torch.no_grad():
            for p, *dlist in zip(global_w, *deltas):
                p.data += sum(sz*d for sz,d in zip(sizes, dlist)) / tot

        # update server control variate
        for j in range(len(server_c)):
            diff = sum((client_c[i][j] - server_c[j]) for i in range(K)) / K
            server_c[j] += diff

        # evaluate immediately
        eval_m = MLP(X_train.shape[1]).to(device).eval()
        with torch.no_grad():
            for p,w in zip(eval_m.parameters(), global_w):
                p.data.copy_(w)
            preds = eval_m(torch.from_numpy(X_test).to(device)).argmax(1).cpu().numpy()

        acc = accuracy_score(y_test, preds)*100
        f1  = f1_score(y_test, preds, average="macro")
        acc_hist.append(acc); f1_hist.append(f1)

        print(f"  Round {rnd+1:3d} → Acc={acc:6.2f}%   Macro-F1={f1:5.3f}")

    return acc_hist, f1_hist

# ---------------------------
# 2) Run & average 3 seeds
# ---------------------------
SEEDS = [42, 43, 44]
all_accs, all_f1s = [], []

for seed in SEEDS:
    a_hist, f_hist = run_scaffold(seed)
    all_accs.append(a_hist)
    all_f1s.append(f_hist)

# per‐seed summary
for seed,a_hist,f_hist in zip(SEEDS,all_accs,all_f1s):
    print(f"\n=== Seed {seed} ===")
    for i,(a,f) in enumerate(zip(a_hist,f_hist),1):
        print(f"Round {i:3d} → Acc={a:6.2f}%   Macro-F1={f:5.3f}")

# average curve
avg_acc = np.mean(all_accs, axis=0)
avg_f1  = np.mean(all_f1s,  axis=0)
print("\n=== Average over 3 runs ===")
for i,(a,f) in enumerate(zip(avg_acc,avg_f1),1):
    print(f"Round {i:3d} → Acc={a:6.2f}%   Macro-F1={f:5.3f}")
