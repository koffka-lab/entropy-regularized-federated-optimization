# ============================================================
#  FedCurv on UNSW-NB15  →  3 runs + per-round averages
# ============================================================
import os, random, numpy as np, pandas as pd, torch, torch.nn as nn, torch.nn.functional as F
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.metrics import accuracy_score, f1_score
from torch.utils.data import DataLoader, TensorDataset

# ---------------------------
# 0) CONFIGURATION
# ---------------------------
DATA_DIR      = "./data"
ROUNDS        = 100
K             = 5
DIRICHLET_α   = 0.5
WARMUP_FRAC   = 0.05
BASE_LR       = 1e-3
LOCAL_EPOCHS  = 1
BATCH_SIZE    = 64
LAMBDA_CURV   = 1.0          # FedCurv penalty
SEEDS         = [42, 43, 44]

# ---------------------------
# 1) MODEL DEFINITION
# ---------------------------
class MLP(nn.Module):
    def __init__(self, in_dim, hidden=64, num_classes=10):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, num_classes))
    def forward(self, x): return self.net(x)

# ---------------------------
# 2) HELPERS
# ---------------------------
def preprocess():
    tr = pd.read_csv(os.path.join(DATA_DIR,"UNSW_NB15_training-set.csv"))
    te = pd.read_csv(os.path.join(DATA_DIR,"UNSW_NB15_testing-set.csv"))

    num_cols = tr.select_dtypes(include="number").columns.drop(["id","label"])
    cat_cols = [c for c in tr.columns if tr[c].dtype=="object" and c!="attack_cat"]

    num_imp = SimpleImputer(strategy="median")
    tr[num_cols] = num_imp.fit_transform(tr[num_cols]); te[num_cols] = num_imp.transform(te[num_cols])
    cat_imp = SimpleImputer(strategy="most_frequent")
    tr[cat_cols] = cat_imp.fit_transform(tr[cat_cols]); te[cat_cols] = cat_imp.transform(te[cat_cols])

    ohe = OneHotEncoder(sparse=False, handle_unknown="ignore")
    tr_cat = ohe.fit_transform(tr[cat_cols]); te_cat = ohe.transform(te[cat_cols])
    scaler = StandardScaler()
    tr_num = scaler.fit_transform(tr[num_cols]); te_num = scaler.transform(te[num_cols])

    Xtr = np.hstack([tr_num, tr_cat]).astype(np.float32)
    Xte = np.hstack([te_num, te_cat]).astype(np.float32)
    ytr = tr["label"].values.astype(int)
    yte = te["label"].values.astype(int)
    return Xtr,Xte,ytr,yte

# Approximate per-parameter Fisher diagonal by running-mean of squared grads
def fisher_diag(model):
    diag = []
    for p in model.parameters():
        if p.grad is None:
            diag.append(torch.zeros_like(p))
        else:
            diag.append(p.grad.detach().pow(2))
    return diag

# ---------------------------
# 3) SINGLE-SEED RUN
# ---------------------------
def run_fedcurv(seed):
    # reproducibility
    random.seed(seed); np.random.seed(seed)
    torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True; torch.backends.cudnn.benchmark = False

    Xtr,Xte,ytr,yte = preprocess()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # ----- warm-up (IID) -----
    n_warm = int(WARMUP_FRAC*len(Xtr))
    warm_idx = np.random.choice(len(Xtr), n_warm, replace=False)
    warm_loader = DataLoader(TensorDataset(
        torch.from_numpy(Xtr[warm_idx]), torch.from_numpy(ytr[warm_idx])),
        batch_size=128, shuffle=True)

    model = MLP(Xtr.shape[1]).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    model.train()
    for xb,yb in warm_loader:
        xb,yb = xb.to(device), yb.to(device)
        opt.zero_grad(); F.cross_entropy(model(xb), yb).backward(); opt.step()

    global_w = [p.data.clone() for p in model.parameters()]
    global_F = [torch.zeros_like(p) for p in model.parameters()]  # curvature accumulator

    # ----- Dirichlet non-IID split -----
    client_idx = {i: [] for i in range(K)}
    for c in np.unique(ytr):
        idx = np.where(ytr==c)[0]
        props = np.random.dirichlet([DIRICHLET_α]*K)
        cuts = (np.cumsum(props)*len(idx)).astype(int)
        prev=0
        for i,pt in enumerate(cuts):
            client_idx[i] += idx[prev:pt].tolist(); prev=pt

    # record metrics
    acc_hist, f1_hist = [],[]

    for rnd in range(ROUNDS):
        deltas, sizes, fishers = [],[],[]

        # ---- local updates ----
        for cid in range(K):
            m = MLP(Xtr.shape[1]).to(device)
            for p,w0 in zip(m.parameters(), global_w): p.data.copy_(w0)
            opt_loc = torch.optim.Adam(m.parameters(), lr=BASE_LR)

            ds = TensorDataset(torch.from_numpy(Xtr[client_idx[cid]]),
                               torch.from_numpy(ytr[client_idx[cid]]))
            loader = DataLoader(ds, batch_size=BATCH_SIZE, shuffle=True)

            m.train()
            # accumulate local Fisher diagonals
            F_i = [torch.zeros_like(p) for p in m.parameters()]

            for _ in range(LOCAL_EPOCHS):
                for xb,yb in loader:
                    xb,yb = xb.to(device), yb.to(device)
                    opt_loc.zero_grad()
                    out = m(xb)
                    loss = F.cross_entropy(out, yb)

                    # FedCurv regularizer
                    reg = 0.0
                    with torch.no_grad():
                        for p,w0,Fg in zip(m.parameters(), global_w, global_F):
                            reg += ((p - w0)**2 * Fg).sum()
                    loss = loss + (LAMBDA_CURV/2.0)*reg

                    loss.backward()
                    # update running fisher for this batch
                    with torch.no_grad():
                        for Fi,p in zip(F_i, m.parameters()):
                            if p.grad is not None: Fi += p.grad.pow(2)
                    opt_loc.step()

            # average fisher over all local batches
            for Fi in F_i: Fi /= max(1,len(loader))
            fishers.append(F_i)
            deltas.append([p.data - w0 for p,w0 in zip(m.parameters(), global_w)])
            sizes.append(len(client_idx[cid]))

        # ---- aggregate weights ----
        tot = sum(sizes)
        with torch.no_grad():
            for p,*dlist in zip(global_w,*deltas):
                p.data += sum(sz*d for sz,d in zip(sizes,dlist)) / tot

            # aggregate diagonal Fishers (mean across clients)
            for j in range(len(global_F)):
                global_F[j] = sum(Fi[j] for Fi in fishers) / K

        # ---- evaluation ----
        m_eval = MLP(Xtr.shape[1]).to(device).eval()
        with torch.no_grad():
            for p,w in zip(m_eval.parameters(), global_w): p.data.copy_(w)
            preds = m_eval(torch.from_numpy(Xte).to(device)).argmax(1).cpu().numpy()

        acc = accuracy_score(yte, preds)*100
        f1  = f1_score(yte, preds, average="macro")
        acc_hist.append(acc); f1_hist.append(f1)
        print(f"[Seed {seed}] Round {rnd+1:3d} → Acc={acc:6.2f}%   Macro-F1={f1:5.3f}")

    return np.array(acc_hist), np.array(f1_hist)

# ---------------------------
# 4) RUN 3 SEEDS & AVERAGE
# ---------------------------
all_acc, all_f1 = [],[]
for s in SEEDS:
    a,f = run_fedcurv(s); all_acc.append(a); all_f1.append(f)

all_acc = np.vstack(all_acc); all_f1 = np.vstack(all_f1)
avg_acc = all_acc.mean(0); avg_f1 = all_f1.mean(0)

print("\n=== AVERAGED OVER 3 RUNS ===")
for i,(a,f) in enumerate(zip(avg_acc,avg_f1),1):
    print(f"Round {i:3d} → Avg Acc={a:6.2f}%   Avg Macro-F1={f:5.3f}")
