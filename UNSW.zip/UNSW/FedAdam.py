"""
FedAdam on UNSW-NB15  (bias-corrected, correct sign)
====================================================
Dirichlet α = 0.5   |   K = 5  non-IID clients
Local  optimiser : Adam   (lr = 1e-3, 1 epoch)
Server optimiser: FedAdam (η = 0.1, β1 = 0.9, β2 = 0.99, τ = 1e-6)
100 rounds, metrics: Accuracy (%) and Macro-F1
Seeds = [42, 43, 44]
"""

import os, random, numpy as np, pandas as pd, torch
import torch.nn as nn, torch.nn.functional as F
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.metrics import accuracy_score, f1_score
from torch.utils.data import TensorDataset, DataLoader

# ───────── hyper-parameters ─────────
DATA_DIR, K, ROUNDS          = "./data", 5, 100
DIRICHLET_A, WARMUP_FR       = 0.5, 0.05
LR_LOCAL, EPOCHS_LOC, BATCH  = 1e-3, 1, 64
SEEDS                        = [42, 43, 44]

# FedAdam server params
ETA_S, B1, B2, TAU = 0.10, 0.9, 0.99, 1e-6
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ───────── model ─────────
class MLP(nn.Module):
    def __init__(self, d_in, h=64, n_out=2):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(d_in, h), nn.ReLU(),
            nn.Linear(h, h), nn.ReLU(),
            nn.Linear(h, n_out))
    def forward(self, x): return self.net(x)

# ───────── data loader ─────────
def load_unsw():
    tr = pd.read_csv(os.path.join(DATA_DIR, "UNSW_NB15_training-set.csv"))
    te = pd.read_csv(os.path.join(DATA_DIR, "UNSW_NB15_testing-set.csv"))

    num = tr.select_dtypes(include="number").columns.drop(["id", "label"])
    cat = [c for c in tr.columns if tr[c].dtype == "object" and c != "attack_cat"]

    impN, impC = SimpleImputer(strategy="median"), SimpleImputer(strategy="most_frequent")
    tr[num], te[num] = impN.fit_transform(tr[num]), impN.transform(te[num])
    tr[cat], te[cat] = impC.fit_transform(tr[cat]), impC.transform(te[cat])

    enc = OneHotEncoder(sparse=False, handle_unknown="ignore")
    trC, teC = enc.fit_transform(tr[cat]), enc.transform(te[cat])
    scl = StandardScaler()
    trN, teN = scl.fit_transform(tr[num]), scl.transform(te[num])

    Xtr = np.hstack([trN, trC]).astype(np.float32)
    Xte = np.hstack([teN, teC]).astype(np.float32)
    ytr, yte = tr.label.values.astype(int), te.label.values.astype(int)
    return Xtr, ytr, Xte, yte

Xtr, ytr, Xte, yte = load_unsw()
D_IN, N_CLASS = Xtr.shape[1], len(np.unique(ytr))

# ───────── single run ─────────
def run(seed: int):
    random.seed(seed); np.random.seed(seed)
    torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)

    # IID warm-up
    idx0 = np.random.choice(len(Xtr), int(WARMUP_FR*len(Xtr)), replace=False)
    warm = MLP(D_IN, n_out=N_CLASS).to(device)
    opt0 = torch.optim.Adam(warm.parameters(), lr=1e-3)
    ld0  = DataLoader(TensorDataset(torch.from_numpy(Xtr[idx0]),
                                    torch.from_numpy(ytr[idx0])),
                      128, shuffle=True)
    warm.train()
    for xb, yb in ld0:
        opt0.zero_grad()
        F.cross_entropy(warm(xb.to(device)), yb.to(device)).backward()
        opt0.step()
    global_w = [p.data.clone() for p in warm.parameters()]

    # server moments
    m_t = [torch.zeros_like(w) for w in global_w]
    v_t = [torch.zeros_like(w) for w in global_w]

    # Dirichlet K-way split
    clients = {i: [] for i in range(K)}
    for c in np.unique(ytr):
        idx = np.where(ytr == c)[0]
        props = np.random.dirichlet([DIRICHLET_A]*K)
        cuts  = (np.cumsum(props)*len(idx)).astype(int)
        s = 0
        for i,e in enumerate(cuts):
            clients[i].extend(idx[s:e].tolist()); s = e

    # ───── rounds ─────
    for r in range(ROUNDS):
        deltas, sizes = [], []

        for cid in range(K):
            loc = MLP(D_IN, n_out=N_CLASS).to(device)
            for p,w in zip(loc.parameters(), global_w): p.data.copy_(w)
            opt_loc = torch.optim.Adam(loc.parameters(), lr=LR_LOCAL)

            ds = TensorDataset(torch.from_numpy(Xtr[clients[cid]]),
                               torch.from_numpy(ytr[clients[cid]]))
            ld = DataLoader(ds, BATCH, shuffle=True)

            loc.train()
            for _ in range(EPOCHS_LOC):
                for xb, yb in ld:
                    opt_loc.zero_grad()
                    F.cross_entropy(loc(xb.to(device)), yb.to(device)).backward()
                    opt_loc.step()

            deltas.append([p.data - w for p, w in zip(loc.parameters(), global_w)])
            sizes.append(len(clients[cid]))

        total = sum(sizes)
        # correct FedAdam gradient:   g_t = w_global − w_local
        g_t = [ -sum(sz * d for sz, d in zip(sizes, grads)) / total
                for grads in zip(*deltas) ]

        with torch.no_grad():
            for i,(w,g) in enumerate(zip(global_w, g_t)):
                m_t[i] = B1 * m_t[i] + (1-B1) * g
                v_t[i] = B2 * v_t[i] + (1-B2) * (g * g)
                m_hat  = m_t[i] / (1 - B1**(r+1))
                v_hat  = v_t[i] / (1 - B2**(r+1))
                w.data -= ETA_S * m_hat / (torch.sqrt(v_hat) + TAU)

        # evaluation
        eval_m = MLP(D_IN, n_out=N_CLASS).to(device).eval()
        with torch.no_grad():
            for p,w in zip(eval_m.parameters(), global_w): p.data.copy_(w)
            preds = eval_m(torch.from_numpy(Xte).to(device)).argmax(1).cpu().numpy()
        acc = accuracy_score(yte, preds)*100
        f1  = f1_score(yte, preds, average="macro")
        print(f"[Seed {seed}] Round {r+1:3d} → Acc={acc:6.2f}%   Macro-F1={f1:5.3f}")

# ───────── execute three seeds ─────────
for s in SEEDS:
    run(s)
