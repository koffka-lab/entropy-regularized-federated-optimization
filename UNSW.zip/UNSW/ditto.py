# ============================================================
# Ditto only (no ERFO), with preprocessing, LR warmup/decay,
# global IID warm-up, run over 3 seeds (42,43,44), printing after each round
# ============================================================

import os
import random
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.metrics import accuracy_score, f1_score
from torch.utils.data import DataLoader, TensorDataset
import torch
import torch.nn as nn
import torch.nn.functional as F

# ---------------------------
# 0) Load & preprocess data once
# ---------------------------
DATA_DIR = "./data"
train_df = pd.read_csv(os.path.join(DATA_DIR, "UNSW_NB15_training-set.csv"))
test_df  = pd.read_csv(os.path.join(DATA_DIR, "UNSW_NB15_testing-set.csv"))

num_cols = train_df.select_dtypes(include="number").columns.drop(["id","label"])
cat_cols = [c for c in train_df.columns if train_df[c].dtype == "object" and c not in ["attack_cat"]]

num_imp = SimpleImputer(strategy="median")
cat_imp = SimpleImputer(strategy="most_frequent")

train_df[num_cols] = num_imp.fit_transform(train_df[num_cols])
test_df[num_cols]  = num_imp.transform(test_df[num_cols])
train_df[cat_cols] = cat_imp.fit_transform(train_df[cat_cols])
test_df[cat_cols]  = cat_imp.transform(test_df[cat_cols])

# Encode & scale
ohe    = OneHotEncoder(sparse=False, handle_unknown="ignore")
scaler = StandardScaler()

train_cat = ohe.fit_transform(train_df[cat_cols])
test_cat  = ohe.transform(test_df[cat_cols])
train_num = scaler.fit_transform(train_df[num_cols])
test_num  = scaler.transform(test_df[num_cols])

X_train = np.hstack([train_num, train_cat]).astype(np.float32)
X_test  = np.hstack([ test_num,  test_cat]).astype(np.float32)
y_train = train_df["label"].values.astype(int)
y_test  = test_df["label"].values.astype(int)

IN_DIM      = X_train.shape[1]
NUM_CLASSES = len(np.unique(y_train))

# ---------------------------
# 1) Model definition
# ---------------------------
class MLP(nn.Module):
    def __init__(self, in_dim, hidden=64, num_classes=NUM_CLASSES):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, num_classes)
        )
    def forward(self, x): return self.net(x)

# ---------------------------
# 2) Local training for Ditto (no ERFO)
# ---------------------------
def local_train_ditto(w0_cpu, z0_cpu, indices, mu, lr, local_epochs, scheduler_fn=None):
    # bring to device
    w0_dev = [w.clone().to(device) for w in w0_cpu]
    z0_dev = [z.clone().to(device) for z in z0_cpu]

    m = MLP(IN_DIM).to(device)
    for p, w0i in zip(m.parameters(), w0_dev):
        p.data.copy_(w0i)

    opt = torch.optim.Adam(m.parameters(), lr=lr)
    sched = scheduler_fn(opt) if scheduler_fn else None

    ds = TensorDataset(
        torch.from_numpy(X_train[indices]),
        torch.from_numpy(y_train[indices])
    )
    loader = DataLoader(ds, batch_size=64, shuffle=True)

    for ep in range(local_epochs):
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.to(device)
            opt.zero_grad()
            out  = m(xb)
            loss = F.cross_entropy(out, yb)
            # Ditto proximal term toward personal model
            prox = sum(((p - z0i)**2).sum() for p, z0i in zip(m.parameters(), z0_dev))
            loss = loss + 0.5 * mu * prox
            loss.backward()
            opt.step()
            if sched: sched.step()

    w_new_cpu = [p.data.clone().cpu() for p in m.parameters()]
    # compute deltas
    deltas_cpu = [w_new_cpu[i] - w0_cpu[i] for i in range(len(w0_cpu))]
    # update personal model (Ditto update rule)
    z_new_cpu = [z0_cpu[i] + 0.1 * (w_new_cpu[i] - z0_cpu[i])
                 for i in range(len(z0_cpu))]
    return deltas_cpu, z_new_cpu

# ---------------------------
# 3) Federated Ditto loop over seeds
# ---------------------------
SEEDS = [42, 43, 44]
ROUNDS           = 100
LOCAL_EPOCHS     = 1
BASE_LR          = 1e-3
MU_DITTO         = 1e-2  # Ditto proximal weight
GLOBAL_WARMUP_FRAC = 0.05
K = 5
alpha = 0.5  # Dirichlet alpha

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

for SEED in SEEDS:
    random.seed(SEED)
    np.random.seed(SEED)
    torch.manual_seed(SEED)
    torch.cuda.manual_seed_all(SEED)

    # 3a) Global IID warm-up
    n_warm = int(GLOBAL_WARMUP_FRAC * len(X_train))
    warm_idx = np.random.choice(len(X_train), n_warm, replace=False)
    warm_ds = TensorDataset(
        torch.from_numpy(X_train[warm_idx]),
        torch.from_numpy(y_train[warm_idx])
    )
    warm_loader = DataLoader(warm_ds, batch_size=128, shuffle=True)

    model = MLP(IN_DIM).to(device)
    opt_warm = torch.optim.Adam(model.parameters(), lr=1e-3)
    for xb, yb in warm_loader:
        xb, yb = xb.to(device), yb.to(device)
        opt_warm.zero_grad()
        loss = F.cross_entropy(model(xb), yb)
        loss.backward()
        opt_warm.step()
    global_w = [p.data.clone().cpu() for p in model.parameters()]

    # init personal copies
    z_cpus = {cid: [w.clone() for w in global_w] for cid in range(K)}

    # Dirichlet split
    labels = y_train
    client_idxs = {i: [] for i in range(K)}
    for c in np.unique(labels):
        idxs = np.where(labels == c)[0]
        props = np.random.dirichlet([alpha]*K)
        cuts = (np.cumsum(props) * len(idxs)).astype(int)
        prev = 0
        for cid, cut in enumerate(cuts):
            client_idxs[cid] += idxs[prev:cut].tolist()
            prev = cut

    def lr_schedule(opt):
        return torch.optim.lr_scheduler.LambdaLR(
            opt,
            lambda step: (step+1)/10 if step<10 else max(0.1, 1 - (step-10)/(ROUNDS-10))
        )

    print(f"\n=== Seed {SEED} starting Ditto only ===")
    for rnd in range(1, ROUNDS+1):
        deltas, sizes = [], []
        for cid in range(K):
            delta_c, z_cpus[cid] = local_train_ditto(
                global_w, z_cpus[cid], client_idxs[cid],
                mu=MU_DITTO, lr=BASE_LR,
                local_epochs=LOCAL_EPOCHS,
                scheduler_fn=lr_schedule
            )
            deltas.append(delta_c)
            sizes.append(len(client_idxs[cid]))

        # aggregate global model on CPU
        tot = sum(sizes)
        for i in range(len(global_w)):
            update = sum(sizes[cid] * deltas[cid][i] for cid in range(K)) / tot
            global_w[i] += update

        # evaluate
        eval_m = MLP(IN_DIM).to(device)
        for p, w_cpu in zip(eval_m.parameters(), global_w):
            p.data.copy_(w_cpu.to(device))
        eval_m.eval()
        xb = torch.from_numpy(X_test).to(device)
        preds = eval_m(xb).argmax(dim=1).cpu().numpy()
        acc = accuracy_score(y_test, preds) * 100
        f1  = f1_score(y_test, preds, average="macro")

        print(f"Seed {SEED} Round {rnd:3d} → Acc={acc:6.2f}%   Macro-F1={f1:5.3f}")
