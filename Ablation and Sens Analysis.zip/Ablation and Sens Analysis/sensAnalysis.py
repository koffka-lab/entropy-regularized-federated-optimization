import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
import numpy as np
import matplotlib.pyplot as plt

# Device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Hyperparameter grids
lambdas = [0.0, 1e-4, 5e-4, 1e-3, 5e-3]
lrs = [1e-2, 5e-3, 1e-3, 5e-4, 1e-4]

# CIFAR-10 data loaders
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465),
                         (0.2470, 0.2435, 0.2616))
])
trainset = torchvision.datasets.CIFAR10(root='./data', train=True,
                                        download=True, transform=transform)
testset = torchvision.datasets.CIFAR10(root='./data', train=False,
                                       download=True, transform=transform)
trainloader = torch.utils.data.DataLoader(trainset, batch_size=128,
                                          shuffle=True, num_workers=2)
testloader = torch.utils.data.DataLoader(testset, batch_size=256,
                                         shuffle=False, num_workers=2)

# Simple CNN model
class SimpleCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 32, 3, padding=1), nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1), nn.ReLU(),
            nn.MaxPool2d(2),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64 * 8 * 8, 128), nn.ReLU(),
            nn.Linear(128, 10)
        )
    def forward(self, x):
        x = self.features(x)
        return self.classifier(x)

# Entropy regularization term
def entropy_reg(logits):
    p = torch.softmax(logits, dim=1)
    ent = -torch.sum(p * torch.log(p + 1e-8), dim=1)
    return ent.mean()

# Initialize results grid
acc_grid = np.zeros((len(lrs), len(lambdas)))

# Sensitivity sweep
num_epochs = 3  # adjust as needed
for i, lr in enumerate(lrs):
    for j, lam in enumerate(lambdas):
        model = SimpleCNN().to(device)
        optimizer = optim.SGD(model.parameters(), lr=lr, momentum=0.9)
        criterion = nn.CrossEntropyLoss()
        # Train
        for epoch in range(num_epochs):
            model.train()
            for inputs, targets in trainloader:
                inputs, targets = inputs.to(device), targets.to(device)
                optimizer.zero_grad()
                outputs = model(inputs)
                loss = criterion(outputs, targets)
                if lam > 0:
                    loss += lam * entropy_reg(outputs)
                loss.backward()
                optimizer.step()
        # Evaluate
        model.eval()
        correct = total = 0
        with torch.no_grad():
            for inputs, targets in testloader:
                inputs, targets = inputs.to(device), targets.to(device)
                outputs = model(inputs)
                _, preds = outputs.max(1)
                correct += preds.eq(targets).sum().item()
                total += targets.size(0)
        acc_grid[i, j] = 100. * correct / total

# Plot heatmap
plt.figure(figsize=(8, 6))
im = plt.imshow(acc_grid, origin='lower', cmap='viridis', 
                extent=[min(lambdas), max(lambdas), min(lrs), max(lrs)],
                aspect='auto')
plt.colorbar(im, label='Test Accuracy (%)')
plt.xscale('log')
plt.yscale('log')
plt.xlabel('Entropy weight λ')
plt.ylabel('Learning rate η')
plt.title('CIFAR-10 Accuracy vs λ and Learning Rate')
plt.show()
