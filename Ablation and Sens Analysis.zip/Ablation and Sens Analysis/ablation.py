import os
import random
import math
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.metrics import accuracy_score, f1_score
from torch.utils.data import DataLoader, TensorDataset

# ─── hyperparameters ─────────────────────────────────────────────
DATA_DIR     = "./data"
K            = 5
ROUNDS       = 100
DIRICHLET_A  = 0.5
WARMUP_FR    = 0.05
BASE_LR      = 1e-3
LOCAL_EPOCHS = 1
BATCH_SIZE   = 64
SEEDS        = [42, 43, 44]
LAM_LIST     = [0.0, 1e-4, 1e-3, 1e-2, 1e-1]

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ─── MLP definition ──────────────────────────────────────────────
class MLP(nn.Module):
    def __init__(self, in_dim, hidden=64, num_classes=2):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, num_classes),
        )
    def forward(self, x):
        return self.net(x)

# ─── load & preprocess UNSW-NB15 ─────────────────────────────────
def load_unsw():
    tr = pd.read_csv(os.path.join(DATA_DIR, "UNSW_NB15_training-set.csv"))
    te = pd.read_csv(os.path.join(DATA_DIR, "UNSW_NB15_testing-set.csv"))

    num_cols = tr.select_dtypes(include="number").columns.drop(["id","label"])
    cat_cols = [c for c in tr.columns if tr[c].dtype=="object" and c!="attack_cat"]

    impN = SimpleImputer(strategy="median")
    impC = SimpleImputer(strategy="most_frequent")
    tr[num_cols], te[num_cols] = impN.fit_transform(tr[num_cols]), impN.transform(te[num_cols])
    tr[cat_cols], te[cat_cols] = impC.fit_transform(tr[cat_cols]), impC.transform(te[cat_cols])

    # UPDATED: use sparse_output instead of sparse
    enc = OneHotEncoder(sparse_output=False, handle_unknown="ignore")
    trC, teC = enc.fit_transform(tr[cat_cols]), enc.transform(te[cat_cols])

    scl = StandardScaler()
    trN, teN = scl.fit_transform(tr[num_cols]), scl.transform(te[num_cols])

    Xtr = np.hstack([trN, trC]).astype(np.float32)
    Xte = np.hstack([teN, teC]).astype(np.float32)
    ytr = tr.label.values.astype(int)
    yte = te.label.values.astype(int)
    return Xtr, ytr, Xte, yte

Xtr, ytr, Xte, yte = load_unsw()
IN_DIM, NUM_CLASSES = Xtr.shape[1], len(np.unique(ytr))

# ─── entropy gradient helper ──────────────────────────────────────
def entropy_grad(model, w0):
    with torch.no_grad():
        delta = torch.cat([
            (p.data - w0i).abs().flatten()
            for p, w0i in zip(model.parameters(), w0)
        ])
        Z = delta.sum().clamp_min(1e-12)
        p_j = delta / Z
        hbar = (p_j * p_j.log()).sum()

        grads, idx = [], 0
        for p, w0i in zip(model.parameters(), w0):
            n = p.numel()
            pj = p_j[idx:idx+n].view_as(p)
            gH = ((hbar - pj.log())/Z) * (p.data - w0i).sign()
            grads.append(gH.clone())
            idx += n
    return grads

# ─── local training with entropy regularization ─────────────────
def local_train(w0, indices, lam, lr, epochs, scheduler=None):
    m = MLP(IN_DIM, num_classes=NUM_CLASSES).to(device)
    for p, w0i in zip(m.parameters(), w0):
        p.data.copy_(w0i)
    opt = torch.optim.Adam(m.parameters(), lr=lr)
    sched = scheduler(opt) if scheduler else None

    ds = TensorDataset(torch.from_numpy(Xtr[indices]), torch.from_numpy(ytr[indices]))
    loader = DataLoader(ds, batch_size=BATCH_SIZE, shuffle=True)

    for _ in range(epochs):
        gH = entropy_grad(m, w0)
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.to(device)
            opt.zero_grad()
            out  = m(xb)
            loss = F.cross_entropy(out, yb)
            for p, gh in zip(m.parameters(), gH):
                if p.grad is not None:
                    p.grad.data += lam * gh.to(device)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(m.parameters(), 1.0)
            opt.step()
            if sched: sched.step()

    return [p.data - w0i for p, w0i in zip(m.parameters(), w0)]

# ─── single‐seed ERFO run ────────────────────────────────────────
def run_erfo(seed, lam0):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark     = False

    # IID warm-up
    n_warm = int(WARMUP_FR * len(Xtr))
    idx0   = np.random.choice(len(Xtr), n_warm, replace=False)
    warm   = MLP(IN_DIM, num_classes=NUM_CLASSES).to(device)
    opt0   = torch.optim.Adam(warm.parameters(), lr=BASE_LR)
    loader0= DataLoader(
        TensorDataset(torch.from_numpy(Xtr[idx0]), torch.from_numpy(ytr[idx0])),
        batch_size=128, shuffle=True
    )
    warm.train()
    for xb, yb in loader0:
        xb, yb = xb.to(device), yb.to(device)
        opt0.zero_grad()
        F.cross_entropy(warm(xb), yb).backward()
        opt0.step()
    global_w = [p.data.clone() for p in warm.parameters()]

    # Dirichlet non-IID split
    clients = {i: [] for i in range(K)}
    for c in np.unique(ytr):
        idxs = np.where(ytr==c)[0]
        props= np.random.dirichlet([DIRICHLET_A]*K)
        cuts = (np.cumsum(props)*len(idxs)).astype(int)
        s = 0
        for i, e in enumerate(cuts):
            clients[i].extend(idxs[s:e].tolist()); s = e

    # Federated rounds
    for r in range(ROUNDS):
        lam_t = lam0 * (1 - r/ROUNDS)
        deltas, sizes = [], []
        for cid in range(K):
            d = local_train(
                global_w, clients[cid], lam_t, BASE_LR, LOCAL_EPOCHS,
                scheduler=lambda opt: torch.optim.lr_scheduler.LambdaLR(
                    opt, lambda step: (step+1)/10 if step<10 else 1.0
                )
            )
            deltas.append(d)
            sizes.append(len(clients[cid]))

        total = sum(sizes)
        with torch.no_grad():
            for p, *dlist in zip(global_w, *deltas):
                update = sum(sz*di for sz,di in zip(sizes, dlist)) / total
                p.data += update

        eval_m = MLP(IN_DIM, num_classes=NUM_CLASSES).to(device).eval()
        with torch.no_grad():
            for p, w in zip(eval_m.parameters(), global_w):
                p.data.copy_(w)
            preds = eval_m(torch.from_numpy(Xte).to(device)).argmax(1).cpu().numpy()
        acc = accuracy_score(yte, preds)*100
        f1  = f1_score(yte, preds, average="macro")
        print(f"[λ₀={lam0:.1e} | Seed={seed}] Round {r+1:3d} → Acc={acc:6.2f}%   Macro-F1={f1:5.3f}")

if __name__ == "__main__":
    for lam0 in LAM_LIST:
        print("\n" + "="*40)
        print(f"Ablation: Initial λ₀ = {lam0}")
        print("="*40)
        for sd in SEEDS:
            run_erfo(sd, lam0)
