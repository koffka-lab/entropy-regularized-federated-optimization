import random
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Subset
from torchvision.transforms import ToTensor
from sklearn.metrics import accuracy_score, f1_score
from tqdm import tqdm
from medmnist import PneumoniaMNIST
import medmnist

# ---------------------------
# Configuration
# ---------------------------
SEEDS = [42, 43, 44]
ROUNDS = 100
CLIENTS = 5
LOCAL_EPOCHS = 1
BASE_LR = 1e-3
BATCH_SIZE = 64
FEDCURV_LAMBDA = 0.1
FISHER_SAMPLES = 128  # number of samples to approximate fisher

medmnist.INFO['pneumoniamnist']['task'] = 'binary-class'

# ---------------------------
# Load PneumoniaMNIST
# ---------------------------
train_data = PneumoniaMNIST(split="train", download=True, transform=ToTensor())
test_data = PneumoniaMNIST(split="test", download=True, transform=ToTensor())
train_labels = np.array([y for _, y in train_data])

# ---------------------------
# Model Definition
# ---------------------------
class CNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(1, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2)
        )
        self.fc = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64*7*7, 128), nn.ReLU(),
            nn.Linear(128, 2)
        )
    def forward(self, x):
        return self.fc(self.conv(x))

# ---------------------------
# Utility: Compute Fisher Diagonal
# ---------------------------
def compute_fisher(global_weights, indices):
    model = CNN().to(device)
    for p, w in zip(model.parameters(), global_weights):
        p.data.copy_(w)
    model.eval()
    fisher = [torch.zeros_like(p) for p in model.parameters()]
    loader = DataLoader(Subset(train_data, indices), batch_size=BATCH_SIZE, shuffle=True)
    num = 0
    for xb, yb in loader:
        xb, yb = xb.to(device), yb.squeeze().long().to(device)
        model.zero_grad()
        out = model(xb)
        loss = F.cross_entropy(out, yb)
        loss.backward()
        # accumulate squared gradients
        for i, p in enumerate(model.parameters()):
            fisher[i] += p.grad.data.pow(2)
        num += 1
        if num * BATCH_SIZE >= FISHER_SAMPLES:
            break
    # average
    fisher = [f / num for f in fisher]
    return fisher

# ---------------------------
# FedCurv Local Training
# ---------------------------
def local_train_fedcurv(global_weights, fisher_diag, indices, lr, local_epochs):
    model = CNN().to(device)
    for p, w in zip(model.parameters(), global_weights):
        p.data.copy_(w)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loader = DataLoader(Subset(train_data, indices), batch_size=BATCH_SIZE, shuffle=True)
    for _ in range(local_epochs):
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.squeeze().long().to(device)
            optimizer.zero_grad()
            out = model(xb)
            ce_loss = F.cross_entropy(out, yb)
            # FedCurv regularization: lambda/2 * sum fisher * (w - w_global)^2
            reg_loss = 0.0
            for p_model, p_global, f in zip(model.parameters(), global_weights, fisher_diag):
                reg_loss += (f * (p_model - p_global).pow(2)).sum()
            reg_loss = (FEDCURV_LAMBDA / 2) * reg_loss
            total_loss = ce_loss + reg_loss
            total_loss.backward()
            optimizer.step()
    return [p.data.clone() for p in model.parameters()]

# ---------------------------
# Non-IID Client Split
# ---------------------------
def get_client_indices(labels):
    client_indices = {i: [] for i in range(CLIENTS)}
    for cls in [0, 1]:
        cls_idxs = np.where(labels == cls)[0]
        np.random.shuffle(cls_idxs)
        splits = np.array_split(cls_idxs, CLIENTS)
        for cid in range(CLIENTS):
            client_indices[cid].extend(splits[cid].tolist())
    return client_indices

# ---------------------------
# Main FedCurv Loop
# ---------------------------
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

all_acc = np.zeros((len(SEEDS), ROUNDS))
all_f1  = np.zeros((len(SEEDS), ROUNDS))

client_idxs = get_client_indices(train_labels)

for s_idx, seed in enumerate(SEEDS):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    
    # initialize global model
    model = CNN().to(device)
    global_w = [p.data.clone() for p in model.parameters()]
    
    for rnd in tqdm(range(ROUNDS), desc=f"FedCurv PneumoniaMNIST Seed {seed}"):
        # compute global fisher diag (average across clients)
        fishers = [compute_fisher(global_w, client_idxs[c]) for c in range(CLIENTS)]
        global_fisher = [sum(f[i] for f in fishers) / CLIENTS for i in range(len(fishers[0]))]
        
        # local updates
        local_ws = []
        for cid in range(CLIENTS):
            w_i = local_train_fedcurv(global_w, global_fisher, client_idxs[cid], BASE_LR, LOCAL_EPOCHS)
            local_ws.append(w_i)
        
        # aggregate global model
        with torch.no_grad():
            for i in range(len(global_w)):
                global_w[i] = sum(local_ws[c][i] for c in range(CLIENTS)) / CLIENTS
        
        # evaluate
        eval_model = CNN().to(device)
        for p, w in zip(eval_model.parameters(), global_w):
            p.data.copy_(w)
        eval_model.eval()
        y_true, y_pred = [], []
        loader = DataLoader(test_data, batch_size=256)
        for xb, yb in loader:
            xb = xb.to(device)
            out = eval_model(xb).argmax(dim=1).cpu().numpy()
            y_pred.extend(out)
            y_true.extend(yb.squeeze().numpy())
        acc = accuracy_score(y_true, y_pred) * 100
        f1  = f1_score(y_true, y_pred, average="macro")
        all_acc[s_idx, rnd] = acc
        all_f1[s_idx, rnd]  = f1

# print per-round and average metrics
for rnd in range(ROUNDS):
    print(f"Round {rnd+1}")
    for s_idx, seed in enumerate(SEEDS):
        print(f"  Seed {seed}: Acc={all_acc[s_idx, rnd]:.2f}%, Macro-F1={all_f1[s_idx, rnd]:.3f}")
    avg_acc = all_acc[:, rnd].mean()
    avg_f1  = all_f1[:, rnd].mean()
    print(f"  Average: Acc={avg_acc:.2f}%, Macro-F1={avg_f1:.3f}\n")
