# ============================================================
#  ERFO on PneumoniaMNIST with 3 seeds, non-IID client split
# ============================================================

import random
import numpy as np
from sklearn.metrics import accuracy_score, f1_score
from torch.utils.data import DataLoader, Subset
import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm import tqdm
from torchvision.transforms import ToTensor
from medmnist import PneumoniaMNIST
import medmnist

# ---------------------------
# Config
# ---------------------------
SEEDS = [42, 43, 44]
ROUNDS = 100
CLIENTS = 5
LOCAL_EPOCHS = 1
BASE_LR = 1e-3
LAM = 1e-2
BATCH_SIZE = 64
WARMUP_FRAC = 0.05

medmnist.INFO['pneumoniamnist']['task'] = 'binary-class'

# ---------------------------
# Load PneumoniaMNIST
# ---------------------------
train_data = PneumoniaMNIST(split="train", download=True, transform=ToTensor())
test_data = PneumoniaMNIST(split="test", download=True, transform=ToTensor())
X_test = torch.stack([x[0] for x in test_data])
y_test = torch.tensor([x[1] for x in test_data])

# ---------------------------
# CNN Model
# ---------------------------
class CNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(1, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2)
        )
        self.fc = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64*7*7, 128), nn.ReLU(),
            nn.Linear(128, 2)
        )
    def forward(self, x): return self.fc(self.conv(x))

# ---------------------------
# Entropy Gradient
# ---------------------------
def entropy_grad(model, w0):
    with torch.no_grad():
        deltas = torch.cat([(p.data - w0i).abs().flatten() for p, w0i in zip(model.parameters(), w0)])
        Z = deltas.sum().clamp_min(1e-12)
        p_j = deltas / Z
        hbar = (p_j * p_j.log()).sum()
        grads = []
        idx = 0
        for p, w0i in zip(model.parameters(), w0):
            n = p.numel()
            pj = p_j[idx:idx+n].view_as(p)
            gH = ((hbar - pj.log())/Z) * (p.data - w0i).sign()
            grads.append(gH.clone())
            idx += n
    return grads

# ---------------------------
# Local training
# ---------------------------
def local_train(w0, indices, lam, lr, local_epochs, scheduler=None):
    m = CNN().to(device)
    for p, w0i in zip(m.parameters(), w0):
        p.data.copy_(w0i)
    opt = torch.optim.Adam(m.parameters(), lr=lr)
    if scheduler: scheduler = scheduler(opt)
    loader = DataLoader(Subset(train_data, indices), batch_size=BATCH_SIZE, shuffle=True)
    for ep in range(local_epochs):
        gH = entropy_grad(m, w0)
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.squeeze().long().to(device)
            opt.zero_grad()
            out = m(xb)
            loss = F.cross_entropy(out, yb)
            for p, gh in zip(m.parameters(), gH):
                if p.grad is not None:
                    p.grad.data += lam * gh.to(device)
            loss.backward()
            opt.step()
            if scheduler: scheduler.step()
    return [p.data - w0i for p, w0i in zip(m.parameters(), w0)]

# ---------------------------
# Client split: by class
# ---------------------------
def get_client_indices(labels):
    client_idxs = {i: [] for i in range(CLIENTS)}
    for cls in [0,1]:
        cls_indices = np.where(labels == cls)[0]
        np.random.shuffle(cls_indices)
        split = np.array_split(cls_indices, CLIENTS)
        for cid in range(CLIENTS):
            client_idxs[cid].extend(split[cid])
    return client_idxs

# ---------------------------
# Main loop
# ---------------------------
all_results = []
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
train_labels = np.array([x[1] for x in train_data])

for seed in SEEDS:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    warmup_size = int(WARMUP_FRAC * len(train_data))
    warmup_idx = np.random.choice(len(train_data), warmup_size, replace=False)
    warmup_loader = DataLoader(Subset(train_data, warmup_idx), batch_size=128, shuffle=True)
    model = CNN().to(device)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    for xb, yb in warmup_loader:
        xb, yb = xb.to(device), yb.squeeze().long().to(device)
        opt.zero_grad()
        loss = F.cross_entropy(model(xb), yb)
        loss.backward()
        opt.step()
    global_w = [p.data.clone() for p in model.parameters()]

    def lr_schedule(opt):
        return torch.optim.lr_scheduler.LambdaLR(
            opt, lambda step: (step+1)/10 if step<10 else max(0.1, 1 - (step-10)/(ROUNDS-10))
        )

    client_idxs = get_client_indices(train_labels)
    acc_hist, f1_hist = [], []

    for rnd in tqdm(range(ROUNDS), desc=f"ERFO PneumoniaMNIST Seed {seed}"):
        deltas, sizes = [], []
        for cid in range(CLIENTS):
            delta = local_train(global_w, client_idxs[cid], lam=LAM,
                                lr=BASE_LR, local_epochs=LOCAL_EPOCHS,
                                scheduler=lr_schedule)
            deltas.append(delta)
            sizes.append(len(client_idxs[cid]))
        tot = sum(sizes)
        with torch.no_grad():
            for i, p in enumerate(global_w):
                update = sum(sizes[cid] * deltas[cid][i] for cid in range(CLIENTS)) / tot
                p.data += update

        model = CNN().to(device)
        for p, w0 in zip(model.parameters(), global_w):
            p.data.copy_(w0)
        model.eval()
        loader = DataLoader(test_data, batch_size=256)
        y_true, y_pred = [], []
        for xb, yb in loader:
            xb = xb.to(device)
            out = model(xb).argmax(1).cpu()
            y_true.extend(yb.squeeze().numpy())
            y_pred.extend(out.numpy())
        acc = accuracy_score(y_true, y_pred) * 100
        f1  = f1_score(y_true, y_pred, average="macro")
        acc_hist.append(acc)
        f1_hist.append(f1)
        print(f"Seed {seed} Round {rnd+1:3d} → Acc={acc:6.2f}%   Macro-F1={f1:5.3f}")

    all_results.append((acc_hist, f1_hist))
