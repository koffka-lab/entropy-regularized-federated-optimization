# ============================================================
# FedAdam on PneumoniaMNIST with 3 seeds, non-IID client split
# ============================================================

import random
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Subset
from torchvision.transforms import ToTensor
from medmnist import PneumoniaMNIST
import medmnist
from sklearn.metrics import accuracy_score, f1_score
from tqdm import tqdm

# ---------------------------
# Configuration
# ---------------------------
SEEDS        = [42, 43, 44]
ROUNDS       = 100
CLIENTS      = 5
LOCAL_EPOCHS = 1
BASE_LR      = 1e-3     # local learning rate
SERVER_LR    = 1e-3     # server (FedAdam) learning rate
BATCH_SIZE   = 64
WARMUP_FRAC  = 0.05

BETA1 = 0.9
BETA2 = 0.999
EPS   = 1e-8

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ensure binary classification
medmnist.INFO['pneumoniamnist']['task'] = 'binary-class'

# ---------------------------
# Data Loading
# ---------------------------
train_data = PneumoniaMNIST(split="train", download=True, transform=ToTensor())
test_data  = PneumoniaMNIST(split="test",  download=True, transform=ToTensor())
train_labels = np.array([y for _, y in train_data])

# ---------------------------
# Model Definition
# ---------------------------
class CNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(1, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2)
        )
        self.fc = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64 * 7 * 7, 128), nn.ReLU(),
            nn.Linear(128, 2)
        )
    def forward(self, x):
        return self.fc(self.conv(x))

# ---------------------------
# Non-IID Client Split by Class
# ---------------------------
def get_client_indices(labels):
    client_idxs = {i: [] for i in range(CLIENTS)}
    for cls in [0, 1]:
        idxs = np.where(labels == cls)[0]
        np.random.shuffle(idxs)
        splits = np.array_split(idxs, CLIENTS)
        for cid in range(CLIENTS):
            client_idxs[cid].extend(splits[cid].tolist())
    return client_idxs

# ---------------------------
# Local Training (FedAvg inner)
# ---------------------------
def local_train(global_weights, indices, lr, local_epochs):
    model = CNN().to(device)
    for p, w in zip(model.parameters(), global_weights):
        p.data.copy_(w)
    optimizer = torch.optim.SGD(model.parameters(), lr=lr)
    loader = DataLoader(Subset(train_data, indices), batch_size=BATCH_SIZE, shuffle=True)
    model.train()
    for _ in range(local_epochs):
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.squeeze().long().to(device)
            optimizer.zero_grad()
            F.cross_entropy(model(xb), yb).backward()
            optimizer.step()
    # return the update (delta)
    return [p.data.clone() - w for p, w in zip(model.parameters(), global_weights)]

# ---------------------------
# Warm-up Initialization
# ---------------------------
def warmup_global():
    n_warm = int(WARMUP_FRAC * len(train_data))
    idx    = np.random.choice(len(train_data), n_warm, replace=False)
    loader = DataLoader(Subset(train_data, idx), batch_size=128, shuffle=True)
    model  = CNN().to(device)
    opt    = torch.optim.Adam(model.parameters(), lr=BASE_LR)
    model.train()
    for xb, yb in loader:
        xb, yb = xb.to(device), yb.squeeze().long().to(device)
        opt.zero_grad()
        F.cross_entropy(model(xb), yb).backward()
        opt.step()
    return [p.data.clone() for p in model.parameters()]

# ---------------------------
# Main FedAdam Loop
# ---------------------------
all_acc = np.zeros((len(SEEDS), ROUNDS))
all_f1  = np.zeros((len(SEEDS), ROUNDS))

for s_idx, seed in enumerate(SEEDS):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    # warm-up global model
    global_w = warmup_global()

    # initialize Adam moments
    m = [torch.zeros_like(w) for w in global_w]
    v = [torch.zeros_like(w) for w in global_w]

    client_idxs = get_client_indices(train_labels)

    for rnd in range(ROUNDS):
        deltas, sizes = [], []
        for cid in range(CLIENTS):
            delta = local_train(global_w, client_idxs[cid], BASE_LR, LOCAL_EPOCHS)
            deltas.append(delta)
            sizes.append(len(client_idxs[cid]))
        total = sum(sizes)

        # weighted average of client updates
        avg_delta = [
            sum(sizes[c] * deltas[c][i] for c in range(CLIENTS)) / total
            for i in range(len(global_w))
        ]

        # FedAdam aggregation
        with torch.no_grad():
            for i in range(len(global_w)):
                m[i] = BETA1 * m[i] + (1 - BETA1) * avg_delta[i]
                v[i] = BETA2 * v[i] + (1 - BETA2) * avg_delta[i].pow(2)
                update = SERVER_LR * m[i] / (torch.sqrt(v[i]) + EPS)
                global_w[i] = global_w[i] + update

        # evaluation
        model = CNN().to(device).eval()
        for p, w in zip(model.parameters(), global_w):
            p.data.copy_(w)

        y_true, y_pred = [], []
        loader = DataLoader(test_data, batch_size=256)
        for xb, yb in loader:
            xb = xb.to(device)
            out = model(xb).argmax(dim=1).cpu().numpy()
            y_pred.extend(out)
            y_true.extend(yb.squeeze().numpy())

        acc = accuracy_score(y_true, y_pred) * 100
        f1  = f1_score(y_true, y_pred, average="macro")
        all_acc[s_idx, rnd] = acc
        all_f1[s_idx, rnd]   = f1

        print(f"[Seed {seed}] Round {rnd+1:3d} → Acc={acc:6.2f}%   Macro-F1={f1:5.3f}")

# averaged metrics
print("\n=== AVERAGED OVER 3 RUNS ===")
for rnd in range(ROUNDS):
    avg_acc = all_acc[:, rnd].mean()
    avg_f1  = all_f1[:, rnd].mean()
    print(f"Round {rnd+1:3d} → Avg Acc={avg_acc:6.2f}%   Avg Macro-F1={avg_f1:5.3f}")
