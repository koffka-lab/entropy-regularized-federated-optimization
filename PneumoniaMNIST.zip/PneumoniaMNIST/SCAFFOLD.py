# ============================================================
#  SCAFFOLD on PneumoniaMNIST with 3 seeds, non-IID client split
# ============================================================

import random
import numpy as np
from sklearn.metrics import accuracy_score, f1_score
from torch.utils.data import DataLoader, Subset
import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm import tqdm
from torchvision.transforms import ToTensor
from medmnist import PneumoniaMNIST
import medmnist

# ---------------------------
# Config
# ---------------------------
SEEDS        = [42, 43, 44]
ROUNDS       = 100
CLIENTS      = 5
LOCAL_EPOCHS = 1
BASE_LR      = 1e-3
BATCH_SIZE   = 64
WARMUP_FRAC  = 0.05

medmnist.INFO['pneumoniamnist']['task'] = 'binary-class'

# ---------------------------
# Load PneumoniaMNIST
# ---------------------------
train_data = PneumoniaMNIST(split="train", download=True, transform=ToTensor())
test_data  = PneumoniaMNIST(split="test",  download=True, transform=ToTensor())

# ---------------------------
# CNN Model
# ---------------------------
class CNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(1, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2)
        )
        self.fc = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64*7*7, 128), nn.ReLU(),
            nn.Linear(128, 2)
        )
    def forward(self, x): return self.fc(self.conv(x))

# ---------------------------
# Client split: by class
# ---------------------------
def get_client_indices(labels):
    client_idxs = {i: [] for i in range(CLIENTS)}
    for cls in [0,1]:
        idxs = np.where(labels == cls)[0]
        np.random.shuffle(idxs)
        splits = np.array_split(idxs, CLIENTS)
        for cid in range(CLIENTS):
            client_idxs[cid].extend(splits[cid].tolist())
    return client_idxs

# ---------------------------
# Local SCAFFOLD training
# ---------------------------
def local_train_scaﬀold(w0, c_global, c_local, indices, lr, epochs, scheduler_fn=None):
    m = CNN().to(device)
    # initialize model
    for p, w0i in zip(m.parameters(), w0):
        p.data.copy_(w0i)
    opt = torch.optim.Adam(m.parameters(), lr=lr)
    sched = scheduler_fn(opt) if scheduler_fn else None

    # control variate difference
    delta_c = [cl - cg for cl, cg in zip(c_local, c_global)]

    loader = DataLoader(Subset(train_data, indices),
                        batch_size=BATCH_SIZE, shuffle=True)
    # one local epoch
    for _ in range(epochs):
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.squeeze().long().to(device)
            opt.zero_grad()
            out = m(xb)
            loss = F.cross_entropy(out, yb)
            loss.backward()
            # apply control variate correction
            for p, dc in zip(m.parameters(), delta_c):
                if p.grad is not None:
                    p.grad.data += dc
            opt.step()
            if sched: sched.step()

    # compute update and new local control variate
    new_ws = [p.data.clone() for p in m.parameters()]
    delta_w = [nw - w0i for nw, w0i in zip(new_ws, w0)]
    # update client control variate:
    # c_local = c_local - c_global + (1/(lr*epochs)) * delta_w
    c_local_new = [
        cl - cg + dw / (lr * epochs)
        for cl, cg, dw in zip(c_local, c_global, delta_w)
    ]
    # return model update and updated local c
    return delta_w, c_local_new

# ---------------------------
# Main loop
# ---------------------------
device       = torch.device("cuda" if torch.cuda.is_available() else "cpu")
train_labels = np.array([y for _,y in train_data])

all_acc = []
all_f1  = []

for seed in SEEDS:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    # warm-up global model
    warm_n    = int(WARMUP_FRAC * len(train_data))
    warm_idx  = np.random.choice(len(train_data), warm_n, replace=False)
    warm_loader = DataLoader(Subset(train_data, warm_idx),
                              batch_size=128, shuffle=True)
    model = CNN().to(device)
    opt   = torch.optim.Adam(model.parameters(), lr=BASE_LR)
    for xb, yb in warm_loader:
        xb, yb = xb.to(device), yb.squeeze().long().to(device)
        opt.zero_grad()
        loss = F.cross_entropy(model(xb), yb)
        loss.backward()
        opt.step()
    global_w = [p.data.clone().to(device) for p in model.parameters()]

    # initialize control variates
    c_global = [torch.zeros_like(p) for p in global_w]
    c_locals = [[cg.clone() for cg in c_global] for _ in range(CLIENTS)]

    def lr_schedule(opt):
        return torch.optim.lr_scheduler.LambdaLR(
            opt, lambda step: (step+1)/10 if step<10 else max(0.1, 1-(step-10)/(ROUNDS-10))
        )

    client_idxs = get_client_indices(train_labels)
    acc_hist, f1_hist = [], []

    for rnd in tqdm(range(ROUNDS), desc=f"SCAFFOLD PneumoniaMNIST Seed {seed}"):
        deltas, sizes = [], []
        # each client's local update
        for cid in range(CLIENTS):
            dw, c_new = local_train_scaﬀold(
                global_w, c_global, c_locals[cid],
                client_idxs[cid], lr=BASE_LR,
                epochs=LOCAL_EPOCHS, scheduler_fn=lr_schedule
            )
            deltas.append(dw)
            c_locals[cid] = c_new
            sizes.append(len(client_idxs[cid]))

        # aggregate global model
        total = sum(sizes)
        with torch.no_grad():
            for i, w0 in enumerate(global_w):
                update = sum(sizes[c]*deltas[c][i] for c in range(CLIENTS)) / total
                w0.data += update

        # aggregate global control variate: average of local diffs
        c_global = [
            cg + sum((c_locals[c][i] - cg) for c in range(CLIENTS)) / CLIENTS
            for i, cg in enumerate(c_global)
        ]

        # evaluate global model
        eval_m = CNN().to(device)
        for p, w0 in zip(eval_m.parameters(), global_w):
            p.data.copy_(w0)
        eval_m.eval()
        y_true, y_pred = [], []
        loader = DataLoader(test_data, batch_size=256)
        for xb, yb in loader:
            xb = xb.to(device)
            out = eval_m(xb).argmax(1).cpu().numpy()
            y_pred.extend(out)
            y_true.extend(yb.squeeze().numpy())
        acc = accuracy_score(y_true, y_pred)*100
        f1  = f1_score(y_true, y_pred, average="macro")
        acc_hist.append(acc)
        f1_hist.append(f1)

        print(f"SCAFFOLD PneumoniaMNIST Seed {seed} Round {rnd+1:3d} → "
              f"Acc={acc:6.2f}%   Macro-F1={f1:5.3f}")

    all_acc.append(acc_hist)
    all_f1.append(f1_hist)

# print per-round averages
acc_avg = np.mean(all_acc, axis=0)
f1_avg  = np.mean(all_f1, axis=0)
print("\nAverage over seeds:")
for rnd in range(ROUNDS):
    print(f"Round {rnd+1:3d} → Avg Acc={acc_avg[rnd]:6.2f}%   Avg Macro-F1={f1_avg[rnd]:5.3f}")
