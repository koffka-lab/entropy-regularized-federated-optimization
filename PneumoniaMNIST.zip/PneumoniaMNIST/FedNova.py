import random
import numpy as np
from sklearn.metrics import accuracy_score, f1_score
from torch.utils.data import DataLoader, Subset
import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm import tqdm
from torchvision.transforms import ToTensor
from medmnist import PneumoniaMNIST
import medmnist

# ---------------------------
# Configuration
# ---------------------------
SEEDS = [42, 43, 44]
ROUNDS = 100
CLIENTS = 5
LOCAL_EPOCHS = 1
BASE_LR = 1e-3
BATCH_SIZE = 64
WARMUP_FRAC = 0.05

medmnist.INFO['pneumoniamnist']['task'] = 'binary-class'

# ---------------------------
# Load PneumoniaMNIST
# ---------------------------
train_data = PneumoniaMNIST(split="train", download=True, transform=ToTensor())
test_data = PneumoniaMNIST(split="test", download=True, transform=ToTensor())

# ---------------------------
# Model Definition
# ---------------------------
class CNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(1, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2)
        )
        self.fc = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64*7*7, 128), nn.ReLU(),
            nn.Linear(128, 2)
        )
    def forward(self, x):
        return self.fc(self.conv(x))

# ---------------------------
# FedNova Local Training
# ---------------------------
def local_train_nova(global_weights, indices, lr, local_epochs):
    model = CNN().to(device)
    for p, w in zip(model.parameters(), global_weights):
        p.data.copy_(w)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loader = DataLoader(Subset(train_data, indices), batch_size=BATCH_SIZE, shuffle=True)
    for epoch in range(local_epochs):
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.squeeze().long().to(device)
            optimizer.zero_grad()
            loss = F.cross_entropy(model(xb), yb)
            loss.backward()
            optimizer.step()
    return [p.data.clone() - w for p, w in zip(model.parameters(), global_weights)]

# ---------------------------
# Non-IID Client Split by Class
# ---------------------------
def get_client_indices(labels):
    client_indices = {i: [] for i in range(CLIENTS)}
    for cls in [0, 1]:
        cls_idxs = np.where(labels == cls)[0]
        np.random.shuffle(cls_idxs)
        splits = np.array_split(cls_idxs, CLIENTS)
        for cid in range(CLIENTS):
            client_indices[cid].extend(splits[cid].tolist())
    return client_indices

# ---------------------------
# Main FedNova Loop
# ---------------------------
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
train_labels = np.array([y for _, y in train_data])

# Containers for metrics: shape (num_seeds, ROUNDS)
all_acc = np.zeros((len(SEEDS), ROUNDS))
all_f1 = np.zeros((len(SEEDS), ROUNDS))

for s_idx, seed in enumerate(SEEDS):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    # Warm-up
    warmup_n = int(WARMUP_FRAC * len(train_data))
    warmup_idx = np.random.choice(len(train_data), warmup_n, replace=False)
    warm_loader = DataLoader(Subset(train_data, warmup_idx), batch_size=128, shuffle=True)
    model = CNN().to(device)
    opt = torch.optim.Adam(model.parameters(), lr=BASE_LR)
    for xb, yb in warm_loader:
        xb, yb = xb.to(device), yb.squeeze().long().to(device)
        opt.zero_grad()
        loss = F.cross_entropy(model(xb), yb)
        loss.backward()
        opt.step()
    global_w = [p.data.clone() for p in model.parameters()]

    client_idxs = get_client_indices(train_labels)

    # Per-round training and evaluation
    for rnd in range(ROUNDS):
        deltas, sizes = [], []
        for cid in range(CLIENTS):
            delta = local_train_nova(global_w, client_idxs[cid], BASE_LR, LOCAL_EPOCHS)
            deltas.append(delta)
            sizes.append(len(client_idxs[cid]))
        total = sum(sizes)
        with torch.no_grad():
            for i, w in enumerate(global_w):
                update = sum(sizes[c] * deltas[c][i] for c in range(CLIENTS))
                update = update / (total * LOCAL_EPOCHS)
                w += update

        # Evaluate
        eval_model = CNN().to(device)
        for p, w in zip(eval_model.parameters(), global_w):
            p.data.copy_(w)
        eval_model.eval()
        y_true, y_pred = [], []
        loader = DataLoader(test_data, batch_size=256)
        for xb, yb in loader:
            xb = xb.to(device)
            out = eval_model(xb).argmax(dim=1).cpu().numpy()
            y_pred.extend(out)
            y_true.extend(yb.squeeze().numpy())
        acc = accuracy_score(y_true, y_pred) * 100
        f1 = f1_score(y_true, y_pred, average="macro")
        all_acc[s_idx, rnd] = acc
        all_f1[s_idx, rnd] = f1

# Print per-round and average metrics
for rnd in range(ROUNDS):
    print(f"Round {rnd+1}")
    for s_idx, seed in enumerate(SEEDS):
        print(f"  Seed {seed}: Acc={all_acc[s_idx, rnd]:.2f}%, Macro-F1={all_f1[s_idx, rnd]:.3f}")
    avg_acc = all_acc[:, rnd].mean()
    avg_f1 = all_f1[:, rnd].mean()
    print(f"  Average: Acc={avg_acc:.2f}%, Macro-F1={avg_f1:.3f}\n")
