import random
import numpy as np
from sklearn.metrics import accuracy_score, f1_score
from torch.utils.data import DataLoader, Subset
import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm import tqdm
from torchvision.transforms import ToTensor
from medmnist import PneumoniaMNIST
import medmnist

# ---------------------------
# Config
# ---------------------------
SEEDS        = [42, 43, 44]
ROUNDS       = 100
CLIENTS      = 5
LOCAL_EPOCHS = 1
BASE_LR      = 1e-3
PROX_COEFF   = 1e-2   # Ditto proximal term coefficient
BATCH_SIZE   = 64
WARMUP_FRAC  = 0.05

medmnist.INFO['pneumoniamnist']['task'] = 'binary-class'

# ---------------------------
# Load PneumoniaMNIST
# ---------------------------
train_data = PneumoniaMNIST(split="train", download=True, transform=ToTensor())
test_data  = PneumoniaMNIST(split="test",  download=True, transform=ToTensor())

# ---------------------------
# CNN Model Definition
# ---------------------------
class CNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(1, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2)
        )
        self.fc = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64*7*7, 128), nn.ReLU(),
            nn.Linear(128, 2)
        )
    def forward(self, x):
        return self.fc(self.conv(x))

# ---------------------------
# Local training with proximal term
# ---------------------------
def local_train(w0, indices, mu, lr, epochs, scheduler_fn=None):
    m = CNN().to(device)
    for p, w0i in zip(m.parameters(), w0):
        p.data.copy_(w0i)
    opt = torch.optim.Adam(m.parameters(), lr=lr)
    sched = scheduler_fn(opt) if scheduler_fn else None

    loader = DataLoader(Subset(train_data, indices), batch_size=BATCH_SIZE, shuffle=True)
    for _ in range(epochs):
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.squeeze().long().to(device)
            opt.zero_grad()
            out = m(xb)
            loss = F.cross_entropy(out, yb)
            prox_loss = 0.0
            for p, w0i in zip(m.parameters(), w0):
                prox_loss += ((p - w0i)**2).sum()
            (loss + (mu/2)*prox_loss).backward()
            opt.step()
            if sched: sched.step()

    return [p.data.clone() - w0i for p, w0i in zip(m.parameters(), w0)]

# ---------------------------
# Client split: by class
# ---------------------------
def get_client_indices(labels):
    client_idxs = {i: [] for i in range(CLIENTS)}
    for cls in [0,1]:
        idxs = np.where(labels == cls)[0]
        np.random.shuffle(idxs)
        splits = np.array_split(idxs, CLIENTS)
        for cid in range(CLIENTS):
            client_idxs[cid].extend(splits[cid].tolist())
    return client_idxs

# ---------------------------
# Main loop
# ---------------------------
device       = torch.device("cuda" if torch.cuda.is_available() else "cpu")
train_labels = np.array([y for _, y in train_data])

all_acc = []
all_f1  = []

for seed in SEEDS:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    # Warm-up global model
    warmup_n = int(WARMUP_FRAC * len(train_data))
    warmup_idx = np.random.choice(len(train_data), warmup_n, replace=False)
    warm_loader = DataLoader(Subset(train_data, warmup_idx), batch_size=128, shuffle=True)
    model = CNN().to(device)
    opt   = torch.optim.Adam(model.parameters(), lr=BASE_LR)
    for xb, yb in warm_loader:
        xb, yb = xb.to(device), yb.squeeze().long().to(device)
        opt.zero_grad()
        F.cross_entropy(model(xb), yb).backward()
        opt.step()

    global_w = [p.data.clone().to(device) for p in model.parameters()]

    def lr_schedule(opt):
        return torch.optim.lr_scheduler.LambdaLR(
            opt,
            lambda step: (step+1)/10 if step < 10 else max(0.1, 1 - (step-10)/(ROUNDS-10))
        )

    client_idxs = get_client_indices(train_labels)
    acc_hist, f1_hist = [], []

    for rnd in tqdm(range(ROUNDS), desc=f"Ditto Seed {seed}"):
        deltas, sizes = [], []
        for cid in range(CLIENTS):
            d = local_train(
                global_w,
                client_idxs[cid],
                mu=PROX_COEFF,
                lr=BASE_LR,
                epochs=LOCAL_EPOCHS,
                scheduler_fn=lr_schedule
            )
            deltas.append(d)
            sizes.append(len(client_idxs[cid]))

        # Aggregate updates
        total = sum(sizes)
        with torch.no_grad():
            for i, w0 in enumerate(global_w):
                update = sum(sizes[c]*deltas[c][i] for c in range(CLIENTS)) / total
                w0.data += update

        # Evaluate
        eval_model = CNN().to(device)
        for p, w0 in zip(eval_model.parameters(), global_w):
            p.data.copy_(w0)
        eval_model.eval()

        y_true, y_pred = [], []
        loader = DataLoader(test_data, batch_size=256)
        for xb, yb in loader:
            out = eval_model(xb.to(device)).argmax(dim=1).cpu().numpy()
            y_pred.extend(out)
            y_true.extend(yb.squeeze().numpy())

        acc = accuracy_score(y_true, y_pred)*100
        f1  = f1_score(y_true, y_pred, average="macro")
        acc_hist.append(acc)
        f1_hist.append(f1)

        print(f"Seed {seed} Round {rnd+1:3d} → Acc={acc:6.2f}%   Macro-F1={f1:5.3f}")

    all_acc.append(acc_hist)
    all_f1.append(f1_hist)

# Compute and print per-round averages across seeds
acc_avg = np.mean(all_acc, axis=0)
f1_avg  = np.mean(all_f1, axis=0)
print("\nAverage over seeds:")
for rnd in range(ROUNDS):
    print(f"Round {rnd+1:3d} → Avg Acc={acc_avg[rnd]:6.2f}%   Avg Macro-F1={f1_avg[rnd]:5.3f}")
